const express=require("express")
const{getHome,getAdmin,getAllTasks,getTask,createTask,updateTask,deleteTask}=require("../controllers/taskController")
// getLogin,getRegister,
const multer = require("multer")
const storage = require("../middleware/multer")
const upload = multer({ storage: storage })

//router instances
let taskRouter=express.Router()

taskRouter.get("/home", getHome)
taskRouter.get("/admin", getAdmin)

taskRouter.get("/list",getAllTasks)

taskRouter.post("/home",upload.single("photo"),createTask)

taskRouter.get("/list/:taskID",getTask)

taskRouter.put("/list/:taskID",updateTask)

taskRouter.delete("/list/:taskID",deleteTask)

module.exports=taskRouter;