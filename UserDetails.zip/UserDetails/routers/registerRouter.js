const express=require("express")
let registerRouter=express.Router()
const{getLogin,getLogout,getRegister,createRegister}=require("../controllers/registerController")


registerRouter.get('/login',getLogin)
registerRouter.get('/logout',getLogout)

registerRouter.get('/register',getRegister)
registerRouter.post('/register',createRegister)

module.exports=registerRouter;