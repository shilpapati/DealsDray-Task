const Task =require("../models/Task")
const getHome = async (req, res) => {
    try {
        res.render("home")
    } catch (error) {
        const err = new Error(error.message)
        err.status = 'fail'
        err.statusCode = 400
        next(err)
    }
}

const getAdmin=async (req, res) => {
    try {
        res.render("admin")
    } catch (error) {
        const err = new Error(error.message)
        err.status = 'fail'
        err.statusCode = 400
        next(err)
    }
}

const getAllTasks=async(req,res)=>{
    try{
        let tasks=await Task.find()
        console.log(tasks)
        res.status(200).render('list',{tasks:tasks})
    }catch(err){
        res.status(400).json({
            status:"fail",
            message:err.message
        })
    }
}

const createTask=async(req,res)=>{
    try{
        let payload=req.body;
        // console.log(payload);
        let photo=req.file
        // console.log(photo);
        let task = await Task.create({...payload,photo:photo})
        console.log(task)
        res.status(201).redirect('/app/v1/tasks/list')
    }catch(err){
        res.status(400).json({
            status:"fail",
            message:err.message
        })
    }
}

const getTask=async(req,res)=>{
    try{
        let id=req.params.taskID
        let task=await Task.findById(id)
        res.status(200).render("update",{task:task})
    }catch(err){
        res.status(400).json({
            status:"fail",
            message:err.message
        })
    }
}


const updateTask=async(req,res)=>{
    try{
        let id=req.params.taskID
        await Task.findByIdAndUpdate(id,req.body,{new:true,runValidators:true})
        res.status(200).redirect('/app/v1/tasks/list')
    }catch(err){
        res.status(400).json({
            status:"fail",
            message:err.message
        })
    }
}

const deleteTask=async(req,res)=>{
    try{
        let id=req.params.taskID
        await Task.findByIdAndDelete(id)
        res.status(200).redirect('/app/v1/tasks/list')
    }catch(err){
        res.status(400).json({
            status:"fail",
            message:err.message
        })
    }
}
module.exports={
    getHome,getAdmin,getAllTasks,getTask, createTask, updateTask, deleteTask
}
// getLogin,getRegister,getLogout,