const Register =require("../models/Register")

const getLogin=async (req,res)=>{
    try {
        
        res.render("landing")
    } catch (error) {
        const err = new Error(error.message)
        err.status = 'fail'
        err.statusCode = 400
        next(err)
    }
}

const getLogout=async (req,res)=>{
    try {
        res.render("landing")
    } catch (error) {
        const err = new Error(error.message)
        err.status = 'fail'
        err.statusCode = 400
        next(err)
    }
}

const getRegister=async (req,res)=>{
    try {
        res.render("register")
    } catch (error) {
        const err = new Error(error.message)
        err.status = 'fail'
        err.statusCode = 400
        next(err)
    }
}
const createRegister=async(req,res)=>{
    try{
        await Register.create(req.body)
        res.status(201).redirect('/login')
    }catch(err){
        res.status(400).json({
            status:"fail",
            message:err.message
        })
    }
}



module.exports={
    getLogin,getLogout,getRegister,createRegister
}