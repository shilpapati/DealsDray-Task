const ensureAuthentication=(req,res,next)=>{
    if(req.isAuthenticated()){
        res.locals.user=req.user
        return next()
    }
    res.redirect('/google/login')
}
module.exports=ensureAuthentication;