const {Schema,model}=require('mongoose')
//Structure
const taskSchema=new Schema({
    userName:{
        type:String,
        required:[true,"UserName is required"],
        trime:true
    },
    email:{
        type:String,
        required:[true,"Email is required"],
        unique:true,
        trime:true
    },
    phone:{
        type:Number,
        required:[true,"Phone is required"],
        unique:true,
        maxlength:10,
        trime:true
    },
    photo:{
        type:[""],
        required:[true,"course image is required"],
    }
    ,gender:{
        type:String,
        Validate:{
            validator:{
                enum:['male','female','other'],
                // required:[true,"Gender is required"]
            }
        }
    },
    course:{
        type:String,
        Validate:{
            validator:{
                enum:['bca','bsc','mca'],
                // required:[true,"Gender is required"]
            }
        }
    }
},
{
    timestamps:true
})
const Task=model("task",taskSchema)
module.exports=Task