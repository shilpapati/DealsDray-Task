const {Schema,model}=require('mongoose')
//Structure
const registerSchema=new Schema({
    userName:{
        type:String,
        required:[true,"UserName is required"],
        trime:true
    },
    email:{
        type:String,
        required:[true,"Email is required"],
        unique:true,
        trime:true
    },
    phone:{
        type:Number,
        required:[true,"Phone is required"],
        unique:true,
        maxlength:10,
        trime:true
    },
    password:{
        type:String,
        required:[true,"password is required"],
        unique:true,
        maxlength:10,
        trime:true
    },
    Cpassword:{
        type:String,
        required:[true,"cpassword is required"],
        unique:true,
        maxlength:10,
        trime:true
    }
},
{
    timestamps:true
})
const Register=model("register",registerSchema)
module.exports=Register